package com.yuliang.tutorial.mum.mpp.lesson7.assignment.labs.prob2;

public interface ClosedCurve {	
	double computePerimeter();
}
