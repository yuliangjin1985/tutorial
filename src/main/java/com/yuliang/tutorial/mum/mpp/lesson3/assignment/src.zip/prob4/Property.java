package com.yuliang.tutorial.mum.mpp.lesson3.assignment.prob4;

public class Property {
    public double computeRent() {
        return 0.0;
    };
}
