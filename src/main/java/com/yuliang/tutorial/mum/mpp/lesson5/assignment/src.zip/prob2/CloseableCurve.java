package com.yuliang.tutorial.mum.mpp.lesson5.assignment.prob2;

public interface CloseableCurve {
    double computeArea();
}