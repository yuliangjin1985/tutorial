<GridPane fx:controller="LoginController"
          xmlns:fx="http://javafx.com/fxml" alignment="center" hgap="10" vgap="10"
          styleClass="root">

The resource files(Login.fxml, Login.css, etc) could not be located in this prob3 path. If there files are in the root src folder(A single)
project, then this will work.