package com.yuliang.tutorial.mum.mpp.lesson2.assignment.prob4;

import java.util.List;

public class Section {
	String courseName;
	int sectionNumber;
	List<TranscriptEntry> gradeSheet;
	
}
