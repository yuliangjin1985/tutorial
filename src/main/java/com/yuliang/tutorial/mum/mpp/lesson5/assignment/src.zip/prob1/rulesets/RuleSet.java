package com.yuliang.tutorial.mum.mpp.lesson5.assignment.prob1.rulesets;

import java.awt.Component;

public interface RuleSet {
	public void applyRules(Component ob) throws RuleException;
}
