package com.yuliang.tutorial.mum.mpp.lesson8.assignment.labs.prob6;

import java.util.Comparator;

public class EmployeeNameComparator {
    public int compare(Employee e1, Employee e2) {
        return e1.getName().compareTo(e2.getName());
    }


}
