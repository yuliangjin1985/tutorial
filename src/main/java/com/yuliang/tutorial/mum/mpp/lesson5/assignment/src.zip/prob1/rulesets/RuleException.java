package com.yuliang.tutorial.mum.mpp.lesson5.assignment.prob1.rulesets;

@SuppressWarnings("serial")
final public class RuleException extends RuntimeException{
	public RuleException() {
		super();
	}
	public RuleException(String msg) {
		super(msg);
	}
}
